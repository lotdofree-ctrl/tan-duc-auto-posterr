package com.tanduc.autoposter;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    final int BG=Color.rgb(16,18,22), PANEL=Color.rgb(25,29,36), PANEL2=Color.rgb(34,40,51);
    final int GOLD=Color.rgb(214,174,85), TXT=Color.rgb(243,240,232), MUTED=Color.rgb(167,170,178);
    DB db; LinearLayout root, body; String selectedMedia="";
    int page=0;

    class DB extends SQLiteOpenHelper {
        DB(Context c){super(c,"tan_duc_mobile.db",null,1);}
        public void onCreate(SQLiteDatabase d){
            d.execSQL("CREATE TABLE groups_list(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,url TEXT NOT NULL UNIQUE,created TEXT)");
            d.execSQL("CREATE TABLE posts(id INTEGER PRIMARY KEY AUTOINCREMENT,content TEXT NOT NULL,media TEXT,created TEXT,status TEXT)");
            d.execSQL("CREATE TABLE post_groups(id INTEGER PRIMARY KEY AUTOINCREMENT,post_id INTEGER,group_id INTEGER,status TEXT,posted TEXT)");
        }
        public void onUpgrade(SQLiteDatabase d,int o,int n){}
    }

    @Override public void onCreate(Bundle b){
        super.onCreate(b); db=new DB(this); getWindow().setStatusBarColor(Color.rgb(11,13,16));
        getWindow().setNavigationBarColor(Color.rgb(11,13,16)); showHome();
    }
    TextView text(String s,int size,int color,boolean bold){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if(bold)t.setTypeface(null,1); t.setPadding(0,dp(4),0,dp(4)); return t;
    }
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density);}
    GradientDrawable bg(int color,int radius){
        GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    LinearLayout horizontal(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    void base(String subtitle){
        root=vertical(); root.setBackgroundColor(BG); setContentView(root);
        LinearLayout header=horizontal(); header.setPadding(dp(16),dp(12),dp(16),dp(12)); header.setBackgroundColor(Color.rgb(11,13,16));
        TextView logo=text("TD",19,BG,true); logo.setGravity(Gravity.CENTER); logo.setBackground(bg(GOLD,10)); logo.setWidth(dp(48)); logo.setHeight(dp(44)); header.addView(logo);
        LinearLayout titles=vertical(); titles.setPadding(dp(12),0,0,0);
        titles.addView(text("TAN DUC AUTO POSTER",17,TXT,true)); titles.addView(text(subtitle,9,GOLD,true)); header.addView(titles,new LinearLayout.LayoutParams(0,-2,1));
        root.addView(header);
        LinearLayout nav=horizontal(); nav.setPadding(dp(10),dp(10),dp(10),dp(8));
        String[] names={"Tổng quan","Hội nhóm","Soạn bài","Hàng đợi"};
        for(int i=0;i<names.length;i++){final int idx=i; Button b=button(names[i],page==i); b.setTextSize(11); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(42),1);lp.setMargins(dp(3),0,dp(3),0);nav.addView(b,lp);b.setOnClickListener(v->{page=idx;render();});}
        root.addView(nav);
        ScrollView sc=new ScrollView(this); body=vertical(); body.setPadding(dp(16),dp(8),dp(16),dp(18)); sc.addView(body); root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        TextView foot=text("Dữ liệu lưu trên điện thoại  •  Bạn luôn xác nhận trước khi đăng",9,GOLD,false); foot.setGravity(Gravity.CENTER); foot.setPadding(dp(8),dp(9),dp(8),dp(9)); foot.setBackgroundColor(Color.rgb(11,13,16)); root.addView(foot);
    }
    Button button(String s,boolean primary){
        Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(primary?BG:TXT);b.setTextSize(13);
        b.setBackground(bg(primary?GOLD:PANEL2,10)); return b;
    }
    EditText edit(String hint,boolean multi){
        EditText e=new EditText(this);e.setHint(hint);e.setTextColor(TXT);e.setHintTextColor(MUTED);e.setTextSize(14);
        e.setPadding(dp(12),dp(10),dp(12),dp(10));e.setBackground(bg(PANEL2,9));
        if(multi){e.setMinLines(4);e.setGravity(Gravity.TOP|Gravity.LEFT);}
        return e;
    }
    void gap(LinearLayout p,int h){View v=new View(this);p.addView(v,new LinearLayout.LayoutParams(1,dp(h)));}
    void section(String s){TextView t=text(s,18,TXT,true);body.addView(t);gap(body,8);}
    void render(){if(page==0)showHome();else if(page==1)showGroups();else if(page==2)showCompose();else showQueue();}
    void showHome(){
        base("FACEBOOK CONTENT MANAGER  •  ANDROID V1"); section("Bảng điều khiển");
        int groups=count("groups_list"), waiting=countWhere("post_groups","status!='Đã xác nhận'"), done=countWhere("post_groups","status='Đã xác nhận'");
        stat("HỘI NHÓM ĐÃ LƯU",groups+" / 50");stat("LƯỢT CHỜ XÁC NHẬN",waiting+"");stat("LƯỢT ĐÃ XÁC NHẬN",done+"");
        LinearLayout card=card();card.addView(text("CÁCH SỬ DỤNG",13,GOLD,true));
        card.addView(text("1. Thêm đường dẫn nhóm Facebook bạn tham gia.\n2. Soạn bài, chọn nhóm và lưu vào hàng đợi.\n3. Mở nhóm, kiểm tra nội dung, tự dán và bấm Đăng.\n4. Quay lại ứng dụng để đánh dấu đã đăng.",13,TXT,false));
        body.addView(card);gap(body,12);
        LinearLayout warn=card();warn.setBackground(bg(Color.rgb(51,41,26),10));warn.addView(text("LƯU Ý FACEBOOK",13,GOLD,true));
        warn.addView(text("Ứng dụng không tự xuất bản vào nhóm. Facebook không cung cấp API đăng bài nhóm cho tài khoản chỉ là thành viên. Không nhập mật khẩu, cookie hoặc mã OTP vào ứng dụng.",12,TXT,false));body.addView(warn);
    }
    void stat(String title,String value){LinearLayout c=card();c.addView(text(title,10,MUTED,true));c.addView(text(value,25,GOLD,true));body.addView(c);gap(body,8);}
    LinearLayout card(){LinearLayout l=vertical();l.setPadding(dp(14),dp(12),dp(14),dp(12));l.setBackground(bg(PANEL,12));return l;}
    int count(String table){Cursor c=db.getReadableDatabase().rawQuery("SELECT COUNT(*) FROM "+table,null);c.moveToFirst();int n=c.getInt(0);c.close();return n;}
    int countWhere(String table,String where){Cursor c=db.getReadableDatabase().rawQuery("SELECT COUNT(*) FROM "+table+" WHERE "+where,null);c.moveToFirst();int n=c.getInt(0);c.close();return n;}
    void showGroups(){
        base("QUẢN LÝ TỐI ĐA 50 HỘI NHÓM");section("Thêm hội nhóm");
        EditText name=edit("Tên hội nhóm",false),url=edit("Đường dẫn nhóm Facebook (https://...)",false);
        body.addView(name);gap(body,8);body.addView(url);gap(body,8);
        Button add=button("＋ Thêm nhóm",true);body.addView(add);add.setOnClickListener(v->{
            String n=name.getText().toString().trim(),u=url.getText().toString().trim();
            if(n.isEmpty()||!(u.startsWith("https://")||u.startsWith("http://"))){toast("Nhập tên và URL hợp lệ.");return;}
            if(count("groups_list")>=50){toast("Danh sách đã đủ 50 nhóm.");return;}
            ContentValues cv=new ContentValues();cv.put("name",n);cv.put("url",u);cv.put("created",now());
            try{db.getWritableDatabase().insertOrThrow("groups_list",null,cv);toast("Đã thêm nhóm.");showGroups();}
            catch(Exception e){toast("Nhóm đã tồn tại hoặc không thể lưu.");}
        });
        gap(body,18);section("Danh sách hội nhóm");
        Cursor c=db.getReadableDatabase().rawQuery("SELECT id,name,url,created FROM groups_list ORDER BY id DESC",null);
        if(c.getCount()==0)body.addView(text("Chưa có hội nhóm. Hãy thêm đường dẫn ở trên.",12,MUTED,false));
        while(c.moveToNext()){
            final int id=c.getInt(0);final String n=c.getString(1),u=c.getString(2);
            LinearLayout item=card();item.addView(text(n,14,TXT,true));item.addView(text(u,10,MUTED,false));
            LinearLayout actions=horizontal();Button open=button("Mở nhóm",false),del=button("Xóa",false);
            actions.addView(open);actions.addView(del);item.addView(actions);body.addView(item);gap(body,7);
            open.setOnClickListener(v->openUrl(u));
            del.setOnClickListener(v->new AlertDialog.Builder(this).setMessage("Xóa nhóm này?").setNegativeButton("Hủy",null).setPositiveButton("Xóa",(a,b)->{db.getWritableDatabase().delete("groups_list","id=?",new String[]{""+id});showGroups();}).show());
        }c.close();
    }
    ArrayList<Integer> chosenIds=new ArrayList<>(); ArrayList<String> chosenNames=new ArrayList<>();
    void showCompose(){
        base("SOẠN NỘI DUNG VÀ CHỌN NHÓM");section("Soạn bài viết");
        EditText content=edit("Nhập nội dung bài viết...",true);body.addView(content);gap(body,8);
        TextView media=text("Chưa chọn ảnh/video",11,MUTED,false);body.addView(media);
        Button pick=button("＋ Chọn ảnh/video",false);body.addView(pick);pick.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"image/*","video/*"});startActivityForResult(i,22);});
        gap(body,12);section("Chọn nhóm nhận bài");
        chosenIds.clear();chosenNames.clear();
        Cursor c=db.getReadableDatabase().rawQuery("SELECT id,name FROM groups_list ORDER BY name",null);
        if(c.getCount()==0)body.addView(text("Bạn chưa thêm nhóm. Hãy vào mục Hội nhóm trước.",12,MUTED,false));
        while(c.moveToNext()){
            int id=c.getInt(0);String n=c.getString(1);CheckBox cb=new CheckBox(this);cb.setText(n);cb.setTextColor(TXT);cb.setButtonTintList(android.content.res.ColorStateList.valueOf(GOLD));body.addView(cb);
            cb.setOnCheckedChangeListener((b,checked)->{if(checked){chosenIds.add(id);chosenNames.add(n);}else{int ix=chosenIds.indexOf(id);if(ix>=0){chosenIds.remove(ix);chosenNames.remove(ix);}}});
        }c.close();
        gap(body,12);EditText sched=edit("Lịch dự kiến (dd/MM/yyyy HH:mm) - tùy chọn",false);body.addView(sched);gap(body,10);
        Button save=button("LƯU VÀO HÀNG ĐỢI",true);body.addView(save);
        save.setOnClickListener(v->{String txt=content.getText().toString().trim();if(txt.isEmpty()){toast("Bạn chưa nhập nội dung.");return;}if(chosenIds.isEmpty()){toast("Hãy chọn ít nhất một nhóm.");return;}
            ContentValues cv=new ContentValues();cv.put("content",txt);cv.put("media",selectedMedia);cv.put("created",now());cv.put("status","Chờ đăng");
            long pid=db.getWritableDatabase().insert("posts",null,cv);
            for(int gid:chosenIds){ContentValues pg=new ContentValues();pg.put("post_id",pid);pg.put("group_id",gid);pg.put("status","Chờ đăng");db.getWritableDatabase().insert("post_groups",null,pg);}
            selectedMedia="";toast("Đã lưu bài vào hàng đợi.");page=3;showQueue();
        });
    }
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(req==22&&res==RESULT_OK&&data!=null){Uri u=data.getData();if(u!=null){selectedMedia=u.toString();toast("Đã chọn tệp. Khi đăng, hãy tự đính kèm tệp trong Facebook.");}}}
    void showQueue(){
        base("CÁC BÀI ĐANG CHỜ VÀ LỊCH SỬ");section("Hàng đợi & lịch sử");
        Cursor c=db.getReadableDatabase().rawQuery("SELECT pg.id,pg.status,p.content,g.name,g.url,p.media FROM post_groups pg JOIN posts p ON p.id=pg.post_id JOIN groups_list g ON g.id=pg.group_id ORDER BY pg.id DESC",null);
        if(c.getCount()==0)body.addView(text("Chưa có bài viết trong hàng đợi.",12,MUTED,false));
        while(c.moveToNext()){
            final int rowId=c.getInt(0);String status=c.getString(1),content=c.getString(2),group=c.getString(3),url=c.getString(4),media=c.getString(5);
            LinearLayout item=card();item.addView(text(status+"  •  "+group,13,GOLD,true));
            String shortText=content.length()>130?content.substring(0,130)+"…":content;item.addView(text(shortText,12,TXT,false));
            if(media!=null&&!media.isEmpty())item.addView(text("Có tệp đính kèm: cần tự chọn lại khi đăng",10,MUTED,false));
            Button prep=button("Mở nhóm + sao chép nội dung",true);item.addView(prep);
            LinearLayout acts=horizontal();Button done=button("Đánh dấu đã đăng",false),pending=button("Chờ đăng",false);acts.addView(done);acts.addView(pending);item.addView(acts);
            body.addView(item);gap(body,8);
            prep.setOnClickListener(v->{((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Nội dung bài viết",content));openUrl(url);new AlertDialog.Builder(this).setTitle("Xác nhận trước khi đăng").setMessage("Đã mở nhóm và sao chép nội dung.\n\nHãy kiểm tra quy định nhóm, dán nội dung, tự đính kèm ảnh/video rồi tự bấm Đăng trên Facebook.").setPositiveButton("Đã hiểu",null).show();});
            done.setOnClickListener(v->new AlertDialog.Builder(this).setMessage("Bạn đã tự đăng bài thành công trong nhóm này?").setNegativeButton("Chưa",null).setPositiveButton("Đã đăng",(a,b)->{ContentValues cv=new ContentValues();cv.put("status","Đã xác nhận");cv.put("posted",now());db.getWritableDatabase().update("post_groups",cv,"id=?",new String[]{""+rowId});showQueue();}).show());
            pending.setOnClickListener(v->{ContentValues cv=new ContentValues();cv.put("status","Chờ đăng");db.getWritableDatabase().update("post_groups",cv,"id=?",new String[]{""+rowId});showQueue();});
        }c.close();
    }
    void openUrl(String u){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(u)));}catch(Exception e){toast("Không mở được đường dẫn.");}}
    String now(){return new SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.getDefault()).format(new Date());}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
