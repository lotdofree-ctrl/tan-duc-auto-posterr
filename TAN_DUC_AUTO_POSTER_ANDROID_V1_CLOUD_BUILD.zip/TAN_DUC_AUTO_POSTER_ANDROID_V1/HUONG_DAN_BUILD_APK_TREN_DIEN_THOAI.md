# Tạo APK bằng điện thoại (không cần PC)

Dự án đã có workflow GitHub Actions để máy chủ GitHub tự biên dịch APK. Bạn cần có tài khoản GitHub và tải toàn bộ mã nguồn này lên một repository.

## Các bước thực hiện trên Android

1. Mở https://github.com và đăng nhập hoặc tạo tài khoản.
2. Tạo repository mới, đặt tên `tan-duc-auto-poster`, chọn **Public** hoặc **Private**, rồi tạo repository.
3. Giải nén ZIP dự án trên điện thoại bằng ứng dụng quản lý tệp.
4. Tải các tệp/thư mục bên trong dự án lên repository, giữ nguyên cấu trúc, đặc biệt phải có thư mục ẩn `.github/workflows/` và tệp `build-apk.yml`. Nếu trình quản lý tệp không hiện thư mục `.github`, bật hiển thị tệp ẩn.
5. Chọn tab **Actions** trong repository. Nếu GitHub hỏi cho phép Actions, chọn **I understand my workflows, go ahead and enable them**.
6. Chọn workflow **Build TAN DUC AUTO POSTER APK**, nhấn **Run workflow** → **Run workflow**.
7. Chờ workflow chạy xong và hiện dấu tick xanh. Mở lần chạy đó, kéo xuống **Artifacts**, nhấn `TAN-DUC-AUTO-POSTER-APK` để tải ZIP chứa APK.
8. Mở ZIP vừa tải, giải nén `app-debug.apk`. Chạm file APK để cài đặt. Nếu Android hỏi, cho phép trình duyệt/trình quản lý tệp **Install unknown apps**. Chỉ cài APK do workflow của repository bạn vừa tạo ra.

## Nếu Actions báo lỗi

Mở lần chạy bị lỗi, chọn bước màu đỏ và gửi ảnh hoặc nội dung lỗi để sửa. Không chia sẻ mật khẩu GitHub, mã xác minh hoặc thông tin đăng nhập Facebook.

## Ghi chú

- Workflow dùng Java 17, Gradle 8.9, Android SDK Platform 35 và Build Tools 35.0.0.
- APK tạo ra là bản debug để cài thử, chưa phải bản phát hành ký số.
- Artifact được GitHub lưu 14 ngày; tải về điện thoại và giữ bản APK riêng.
- App là công cụ chuẩn bị nội dung và mở nhóm; người dùng vẫn tự kiểm tra, đính kèm media và xác nhận đăng trong Facebook.
