# TAN DUC AUTO POSTER – Android V1

## Trạng thái
Đây là dự án Android native (Java). Đã bổ sung GitHub Actions để máy chủ GitHub tự biên dịch APK mà không cần cài Android Studio trên điện thoại. Xem `HUONG_DAN_BUILD_APK_TREN_DIEN_THOAI.md`. APK chưa được biên dịch trong gói ZIP này; cần chạy workflow GitHub để tạo APK.

## Tính năng V1
- Giao diện đen – vàng gold.
- Quản lý tối đa 50 hội nhóm (tên + URL).
- Soạn bài viết, chọn nhiều nhóm.
- Chọn ảnh/video từ điện thoại.
- Lưu hàng đợi và lịch sử theo từng nhóm.
- Mở nhóm Facebook và sao chép nội dung vào clipboard.
- Người dùng tự kiểm tra, đính kèm media và bấm Đăng.
- Đánh dấu đã đăng hoặc chờ đăng.
- Dữ liệu SQLite lưu cục bộ trên điện thoại.

## Build APK bằng Android Studio
1. Trên máy tính, cài Android Studio bản mới từ https://developer.android.com/studio
2. Giải nén `TAN_DUC_AUTO_POSTER_ANDROID_V1.zip`.
3. Mở Android Studio → Open → chọn thư mục `TAN_DUC_AUTO_POSTER_ANDROID_V1`.
4. Chờ Gradle Sync hoàn tất. Nếu được hỏi, cài Android SDK Platform 35 và Build Tools.
5. Chọn Build → Build Bundle(s) / APK(s) → Build APK(s).
6. Sau khi build thành công, chọn Locate trong thông báo để tìm APK (thường ở `app/build/outputs/apk/debug/app-debug.apk`).
7. Chuyển APK sang Android, mở tệp và cho phép cài ứng dụng từ nguồn này nếu Android hỏi.

## Lưu ý về Facebook
- Ứng dụng không tự đăng hàng loạt vào nhóm. Facebook không cung cấp API Groups cho trường hợp tài khoản chỉ là thành viên.
- Không nhập mật khẩu, cookie, token hoặc OTP Facebook vào app.
- Chức năng lịch trong V1 là ghi chú thời gian dự kiến, chưa tự chạy nền để đăng đúng giờ.
- Tệp ảnh/video được chọn qua bộ chọn tệp Android. Bản V1 lưu URI tệp để nhắc bạn tự đính kèm khi đăng; ứng dụng không tự upload lên Facebook.

## Mã ứng dụng
- Package: `com.tanduc.autoposter`
- Min Android: 6.0 (API 23)
- Version: 1.0
